package thi_c09.sercive;

public interface IPhone {
    public void addPhone();
    public void removePhone();
    public void displayPhone();
    public void searchPhone();

}
